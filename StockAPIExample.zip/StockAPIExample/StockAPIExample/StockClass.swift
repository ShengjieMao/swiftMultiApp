//
//  StockClass.swift
//  StockAPIExample
//
//  Created by Shengjie Mao on 12/9/23.
//

import Foundation

class StockClass {
    var city: String = "" //here
    var temperature: Float = 0.0 //here
    var condition: String = "" //here
}
