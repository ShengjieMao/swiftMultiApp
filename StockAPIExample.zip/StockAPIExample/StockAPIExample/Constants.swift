//
//  Constants.swift
//  StockAPIExample
//
//  Created by Shengjie Mao on 12/9/23.
//

import Foundation

let baseURL = "https://us-central1-fir-api-s-8d31b.cloudfunctions.net/app"
//let apiKey = "b77ab5fd66c520edcbf1171660c8ae04" // here
