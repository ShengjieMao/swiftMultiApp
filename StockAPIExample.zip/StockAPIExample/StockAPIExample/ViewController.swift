//
//  ViewController.swift
//  StockAPIExample
//
//  Created by Shengjie Mao on 12/9/23.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftSpinner

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var stockValues: [StockClass] = [StockClass]()
    var stockNames = ["Seattle", "San Francisco", "Portland", "New York", "Miami"] // here
    
    @IBOutlet weak var tblView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func getStockValues(_ sender: Any) {
        var stocks = ""
        for stock in stockNames {
            stocks.append("\(stock),")
        }
        let url = "\(baseURL)"
        print(url)
        SwiftSpinner.show("Getting Weather Values")
        AF.request(url).responseJSON{ response in
            SwiftSpinner.hide()
            if response.error != nil {
                print(response.error?.localizedDescription ?? "Error")
                return
            }
            guard let rawData = response.data else {return}
            guard let jsonArray = JSON(rawData).array else {return}
            
            self.stockValues = [StockClass]()
            for stockJSON in jsonArray {
                print("City : \(stockJSON)")
                let city = stockJSON["city"].stringValue
                let temperature = stockJSON["temperature"].floatValue
                let condition = stockJSON["condition"].stringValue
                
                let stockClass = StockClass()
                stockClass.city = city
                stockClass.temperature = temperature
                stockClass.condition = condition
                self.stockValues.append(stockClass)
            }
            self.tblView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        stockValues.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let symbol = stockValues[indexPath.row].city
        let price = stockValues[indexPath.row].temperature
        let condition = stockValues[indexPath.row].condition
        cell.textLabel?.text = "City: \(symbol) Temperature: \(price) Condition:  \(condition)"
        return cell
    }
    
}

