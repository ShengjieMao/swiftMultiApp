//
//  SendNamePhoneNumberDelegate.swift
//  NamePhoneNumberProtocolDelegate
//
//  Created by Shengjie Mao on 12/9/23.
//

import Foundation

protocol SendNamePhoneNumberDelegate{
    func sendNamePhoneNumber(name: String, phoneNumber: String)
}

